package com.gover.zachary.datadisplayfragments;

interface ListListener {
	void switchObj();
}
